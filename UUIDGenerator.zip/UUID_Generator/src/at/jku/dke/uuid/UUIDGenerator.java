package at.jku.dke.uuid;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

public class UUIDGenerator {
  
  /**
   * 
   * @param args qualified file name where generated UUID is written to.
   */
  public static void main(String[] args) {
    try (PrintWriter writer = new PrintWriter(args[0], "UTF-8")) {
      UUID uuid = UUID.randomUUID();
      writer.write(uuid.toString());
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}
